### ARC.utils.R:  master file for the ARC.utils package, a package consisting of utility functions often used at ARC (Altitude Research Center).

### "CONSTANTS"

EPSILON <- sqrt(.Machine$double.eps) # when we need a very small number

PVALADJ_PRECISION <- 5 # round q-values to five significant figures by default
FDR_LOW <- 0.01 # default q-value cutoff to be used for significance
FDR_HIGH <- 0.05 # alternate, less restrictive default q-value cutoff

NCORES <- max(1, detectCores()-2) # try to leave some free for other stuff

COLOR_BREWER_VALUE_PALETTE <- rev(brewer.pal(10, "RdYlBu")) # "up to down"

NEUTRAL_COLORS <- data.frame(
	hex   = c("#EFEAC4", "#DDDDDD"),
	red   = c(239, 204),
	green = c(234, 204),
	blue  = c(196, 204),
	stringsAsFactors=FALSE
)
rownames(NEUTRAL_COLORS) <- c("tan", "gray")
CBVP_WITH_ZERO <- c(COLOR_BREWER_VALUE_PALETTE[1:5],
                   NEUTRAL_COLORS["gray", "hex"],
                   COLOR_BREWER_VALUE_PALETTE[6:10])

### FUNCTIONS

# Wrapper for dplyr::arrange() that preserves row names and attributes.
arrange_with_attributes <- function(x, ...)
{
	stopifnot(is.data.frame(x))
	
	if("rownames_preservation_column" %in% names(x))
		stop("'names(x)' cannot contain 'rownames_preservation_column'")
	x$rownames_preservation_column = rownames(x)
	y = arrange(x, ...)
	
	rownames(y) = y$rownames_preservation_column
	y$rownames_preservation_column = NULL
	y = copyattr(y, x)
	class(y) = class(x)
	attr(y, "extra.class") = attr(x, "extra.class")
	
	return(y)
}

# Wrapper for dplyr::arrange() that preserves row names.
arrange_with_rownames <- function(x, ...)
{
	stopifnot(is.data.frame(x))
	if("rownames_preservation_column" %in% names(x))
		stop("'names(x)' cannot contain 'rownames_preservation_column'")
	x$rownames_preservation_column = rownames(x)
	x = arrange(x, ...)
	rownames(x) = x$rownames_preservation_column
	x$rownames_preservation_column = NULL
	return(x)
}

# Take a named list and assign the names of each element of list `x` as an attribute of that element, by default with the name "name".
attrname <- function(x, name="name")
{
	if(is.null(names(x))) stop("'x' must have non-NULL names")
	for(nm in names(x)) attr(x[[nm]], name) = nm
	return(x)
}

# Create a design matrix of categorical variable to be used as a regression predictor.  Argument `pred` may be either a vector of categorical predictors such as time, patient, group, etc., or a list (including a data frame) of such predictors.  In the list case, all predictors must be of the same length.  Returns a matrix with the column names showing the predictors.  If `levels` is not NULL, it should be a character vector giving factor levels to be used in ordering the columns of the return value.  In this case, all column names of the return value must be present in `levels` (although the reverse is not true).  If `levels` is not NULL and `fill` is TRUE (`fill` has no effect if `levels` is NULL) then any missing levels will be filled in; i.e. the return value will have a column for every level in `levels` even if there are no occurrences of that level in the data in `pred`.
categorical_design_matrix <- function(pred, levels=NULL, fill=FALSE)
{
	# initial return value
	if(is.list(pred)) {
		if(is.null(names(pred)))
			names(pred) = paste("pred", 1:length(pred), sep="")
		pred = attrname(pred, "type")
		res = lapply(pred, categorical_design_matrix)
		retn = do.call(cbind, res)
		if(is.data.frame(pred)) rownames(retn) = rownames(pred)
	} else {
		upred = unique(pred)
		n = length(upred)
		retn = (diag(n)==1)[match(pred, upred), , drop=FALSE]
			# "(diag(n)==1)" so result will be logical rather than 0/1
		rownames(retn) = names(pred)
		colnames(retn) = upred
	}
	
	# order and fill in PRN, then return
	if(!is.null(levels)) {
		stopifnot(all(colnames(retn) %in% levels))
		if(fill) {
			miss = setdiff(levels, colnames(retn))
			nmiss = length(miss)
			if(nmiss > 0) {
				addon = matrix(FALSE, nrow=nrow(retn), ncol=nmiss)
				colnames(addon) = miss
				retn = cbind(retn, addon)
			}
		}
		ord = order(factor(colnames(retn), levels=levels))
		retn = retn[, ord, drop=FALSE]
	}
	return(retn)
}

# Given a string `x`, format with a header underneath consisting of `char` (by default, hyphen) of the same length, and print as a header.  The function catprint() is a convenience wrapper that takes an object, prints its name, then prints the object itself.
cathead <- function(x, char="-", head=1, tail=2, output=TRUE)
{
	stopifnot(is.character(x))
	stopifnot(is.character(char))
	stopifnot(nchar(char)==1)
	
	y = paste(rep(char, nchar(x)), collapse="")
	h = paste(rep("\n", head), collapse="")
	t = paste(rep("\n", tail), collapse="")
	z = paste(h, x, "\n", y, t, sep="")
	
	if(output) cat(z)
	return(z)
}
catprint <- function(x, ...)
{
	nm = deparse(substitute(x))
	cathead(nm, ...)
	print(x)
}

# Given two matrices or data frames with the same number of rows, and potentially overlapping column names, cbind_overlap() binds the columns and either overwrites the overlapping columns in `y` with those in `x` (the default) or overwrites those in `x` with those in `y` (if use.x is FALSE) and rbind_overlap() does the same with rows for two matrices or data frames having the same number of columns.  Return value is always a data frame.
cbind_overlap <- function(x, y, use.x=TRUE)
{
	# sanity checks
	stopifnot(isMDF(x))
	stopifnot(isMDF(y))
	stopifnot(nrow(x)==nrow(y))
	
	# data munging
	x = as.data.frame(dimformat(x))
	y = as.data.frame(dimformat(y))
	
	# drop overlapping columns as appropriate, return combined
	if(use.x)
		y = y[setdiff(names(y), names(x))]
	else
		x = x[setdiff(names(x), names(y))]
	cbind(x, y)
}
rbind_overlap <- function(x, y, use.x=TRUE)
{
	# sanity checks and data munging
	stopifnot(isMDF(x))
	stopifnot(isMDF(y))
	stopifnot(ncol(x)==ncol(y))
	
	# data munging
	x = as.data.frame(dimformat(x))
	y = as.data.frame(dimformat(y))
	
	# drop overlapping rows as appropriate, return combined
	if(use.x)
		y = y[setdiff(rownames(y), rownames(x)), ]
	else
		x = x[setdiff(rownames(x), rownames(y)), ]
	rbind(x, y)
}

# Given a vector "x", optionally names or indices "i", return the subset of "x" representing "x[i]", by default _without_ partial matching on names.  Argument "partial", if TRUE, allows partial matching.  If "adjust.names" is TRUE, then if "i" is a character vector, then the names will be set to those values.
setMethodS3("chop", "default",
function(x, i=NULL, partial=FALSE, adjust.names=TRUE, ...)
{
	if(is.null(i)) i = 1:length(x)
	idx = if(is.character(i))
		if(partial)
			pmatch(i, names(x), duplicates.ok=TRUE)
		else match(i, names(x))
	else i
	retn = x[idx]
	if(adjust.names) if(is.character(i)) names(retn) = i
	copyattr(retn, x)
	
}, conflict="quiet")
# Given a matrix or data frame "x", optionally row names or indices "rows", and optionally column names or indices "cols", return the subset of "x" representing "x[rows, cols]", by default _without_ partial matching on either row or column names which is unfortunately not a behavior we can require in the built-in"`[.data.frame`".  Arguments "row.partial" and "col.partial", if TRUE, allow partial matching.  If "adjust.names" is TRUE, then if "rows" (and optionally "cols") is a character vector, then the rownames (and optionally column names) will be set to those values.  If "to.matrix" is TRUE, then one-column data frames will be converted to matrices before returning.  If "drop" is TRUE, the result is coerced to the lowest possible dimension.
setMethodS3("chop", "data.frame",
function(x, rows=NULL, cols=NULL, row.partial=FALSE, 
	col.partial=FALSE, adjust.names=TRUE, to.matrix=TRUE, drop=TRUE, ...)
{	
	if(!isMDF(x)) stop("'x' must be a matrix or data frame")
	if(is.null(rows)) rows = 1:nrow(x)
	if(is.null(cols)) cols = 1:ncol(x)
	
	row.idx = if(is.character(rows))
		if(row.partial)
			pmatch(rows, rownames(x), duplicates.ok=TRUE)
		else match(rows, rownames(x))
	else rows
	
	col.idx = if(is.character(cols))
		if(col.partial)
			pmatch(cols, colnames(x), duplicates.ok=TRUE)
		else match(cols, colnames(x))
	else cols
	
	retn = x[row.idx, col.idx, drop=FALSE]
	if(adjust.names) {
		if(is.character(rows)) rownames(retn) = rows
		if(is.character(cols)) colnames(retn) = cols
	}
	if(to.matrix && is.data.frame(retn) && (ncol(retn)==1))
		retn = as.matrix(retn)
	if(drop) retn = drop(retn)
	
	copyattr(retn, x)

}, conflict="quiet")
setMethodS3("chop", "matrix",
function(x, rows=NULL, cols=NULL, row.partial=FALSE, 
	col.partial=FALSE, adjust.names=TRUE, to.matrix=TRUE, drop=TRUE, ...)
{
	x = asdfattr(x)
	x = chop.data.frame(x, rows=rows, cols=cols, row.partial=row.partial,
			col.partial=col.partial, adjust.names=adjust.names, to.matrix=to.matrix, drop=drop, ...)
	asmatattr(x)
}, conflict="quiet")

# Return a printable "collapsed" version of a vector `x`.  If `space` is TRUE, then the elements will be set off by spaces.  If `quote` is TRUE, then single quotes will be added around the elements of the vector. If `as.expr` is TRUE, the string will be rendered as an expression which can be parsed with `evpat`, e.g. collapse_vec(1:3, as.expr=TRUE) = "c(1, 2, 3)".  Beware of using any other separator `sep` than "," if expr is TRUE.
collapse_vec <- function(x, space=TRUE, quote=FALSE, as.expr=FALSE, sep=",")
{	
	collapse = sprintf(ifelse(space, "%s ", "%s"), sep)
	if(quote) x = sprintf("'%s'", x)
	
	retn = sprintf("(%s)", paste(x, collapse=collapse))
	if(as.expr) retn = paste("c", retn, sep="")
	return(retn)
}

# Given a matrix or data frame `x`, report for each column the number of unique elements, the number of elements that are NA, and the minimum and maximum string lengths of the elements.
column_count_report <- function(x)
{
	retn = as.data.frame(rbind(
		unique = apply(x, 2, function(y) length(unique(y))),
		num.na = apply(x, 2, function(y) sum(is.na(y))),
		mincha = apply(x, 2, function(y) min(nchar(y[!is.na(y)]))),
		maxcha = apply(x, 2, function(y) max(nchar(y[!is.na(y)])))))
	retn = extra.class(retn, "column_count_report")
	attr(retn, "xnrow") = nrow(x)
	attr(retn, "xclass") = class(x)
	return(retn)
}
setMethodS3("print", "column_count_report",
function(x, ...)
{
	cat(sprintf("%s with %i rows\n", attr(x, "xclass"), attr(x, "xnrow")))
	print.data.frame(x)
	invisible(x)

}, conflict="quiet")

# Given two objects `x` and `y`, get the attributes from `y` and attach them to the attributes of `x`, "excluding those named in `exclude`, by default attributes not normally part of the attributes list for lists and vectors ("names"), matrices ("dim" and "dimnames"), Matrix objects ("x", "Dim", "Dimnames", "factors", and "class"), or data frames ("names", "row.names", and "class").  Convenience functions are provided for conversion to matrices and data frames, and for transposition, while keeping attributes.
copyattr <- function(x, y, exclude=c("names", "dim", "dimnames", 
	"x", "Dim", "Dimnames", "factors", "class", "row.names"))
{
	tomerge = setdiff(names(attributes(y)),
	                        union(names(attributes(x)), exclude))
	xc = attr(x, "extra.class")
	attributes(x) = c(attributes(x), attributes(y)[tomerge])
	extra.class(x, xc)
}
asmatattr <- function(x) copyattr(as.matrix(x), x)
asdfattr <- function(x) copyattr(as.data.frame(x), x)
tattr <- function(x) copyattr(t(x), x)

# Calculate p-value for given Pearson correlation(s) rho, calculated from n samples.  By default, the p-value is for a test of the hypothesis that rho != 0; if alternative is "less" then the test is for the hypothesis that rho < 0, and similarly for "greater".  If "drop" is TRUE, then the result will be "dropped", i.e. reduced to its lowest dimension.
cor_pvalue <- function(rho, n, cosine=FALSE, df=(if(cosine) n-1 else n-3),
	alternative=c("two.sided", "less", "greater"), drop=TRUE)
{
	rho = as.matrix(rho)
	df = matrix(rep(df, length.out=length(rho)), ncol=ncol(rho))
	stopifnot(min(n-df) > 0)
	df[df <= 0] = NA
	dimnames(df) = dimnames(rho)
	alternative = match.arg(alternative)
	z = atanh(rho) * sqrt(df)
	retn = if(alternative=="two.sided")
		pchisq(z^2, 1, lower.tail=FALSE)
	else
		pnorm(z, 0, 1, lower.tail=(alternative=="less"))
	if(drop) drop(retn) else retn
}

# Given a vector, matrix, or data frame `x`, and optionally a second such data structure `y`, report on the correlations between them and the p-values and standard errors of the correlations.  Arguments `method`, `cosine`, `group`, `use`, and `ranked` are passed to flexcor().  Argument `alternative` controls the calculation of p-values.  Return value is a list with elements "cor" and "pval".
correlation_report <- function(x, y=x, method=c("pearson", "lorenz"), 
	cosine=FALSE, group=NULL, use=c("all.obs", "pairwise.complete.obs"), ranked=FALSE, alternative=c("two.sided", "less", "greater"))
{
	# extract parameters
	method = match.arg(method)
	use = match.arg(use)
	alternative = match.arg(alternative)
	
	# munge data as needed
	x = dimformat(x)
	y = dimformat(y)
	if(!is.null(group)) names(group) = rownames(x)
	common = intersect(rownames(x), rownames(y))
	stopifnot(length(common) > 2)
	x = x[common, , drop=FALSE]
	y = y[common, , drop=FALSE]
	if(!is.null(group)) group = group[common]
	
	# correlation and p-value
	cor = flexcor(x, y, method=method, cosine=cosine,
		group=group, use=use, ranked=ranked)
	n = crossprod(!is.na(x), !is.na(y))
	df = switch(method, pearson=n-1, lorenz=n-length(unique(group)))
	if(!cosine) df = df-2
	pval = cor_pvalue(cor, n=n, df=df,
		cosine=cosine, alternative=alternative, drop=FALSE)
	cor[is.na(pval)] = NA
		# only report correlations for which we can calculate a p-value
	
	# package it up, send it back
	extra.class(named_list(cor, pval, n), "correlation_report")
}
# Given an object of class correlation_report, optionally specific row and column indices, and arguments to be passed to pvaladj(), return a long form report.
setMethodS3("summary", "correlation_report",
function(x, rows=rownames(x$cor), cols=colnames(x$cor), give.n=FALSE,
	qval.method="BH", qval.precision=PVALADJ_PRECISION, qval.n=NULL, ...)
{
	idx = cbind(row=rows, col=cols)
	retn = data.frame(cor=x$cor[idx])
	retn$rsq = retn$cor^2
	retn$pval = x$pval[idx]
	retn$qval = pvaladj(retn$pval, method=qval.method,
		n=qval.n, precision=qval.precision)
	if(give.n) retn$n = x$n[idx]
	extra.class(retn, "summary.correlation_report")
	
}, conflict="quiet")

# Given a matrix or vector "x" and optionally a matrix or vector "y", return the cosine correlation (a.k.a. cosine similarity) between them.  The "..." argument has no effect but is there to allow compatibility with functions that call cor() with arguments not present in coscor().  Note that WGCNA has a "cosine" argument to its cor() function and so in most cases that should be used preferentially to this function, but this function is still useful in cases (such as here in include_utilities.R) where WGCNA has not yet been loaded.
coscor <- function(x, y=x, drop=FALSE,
	use=c("all.obs", "pairwise.complete.obs"), ...)
{
	if(!is.matrix(x)) x = as.matrix(x)
	if(!is.matrix(y)) y = as.matrix(y)
	use = match.arg(use)
	numNA = sum(is.na(x)) + sum(is.na(y))
	if((numNA > 0) && (use=="pairwise.complete.obs")) {
		x[is.na(y)] = NA
		y[is.na(x)] = NA
		x = na.sub(x, 0)
		y = na.sub(y, 0)
	}
	xnorm = sqrt(colSums(x^2))
	ynorm = sqrt(colSums(y^2))
	retn = crossprod(x, y) / tcrossprod(xnorm, ynorm)
	retn[retn > 1] = 1 ; retn[retn < -1] = -1
		# deal with numerical instability
	if(drop) drop(retn) else retn
}

# Convenience wrappers for write.csv(...) and write.table(..., sep="\t", ...) that give the usual formatting options we want:  no quotes, no row names, and NAs represented by blanks.
csvwrite <- function(x, file="", quote=FALSE, row.names=FALSE, na="", ...)
	write.csv(x, file=file, quote=quote, row.names=row.names, na=na, ...)
tsvwrite <- function(x, file="", quote=FALSE, row.names=FALSE, na="", ...)
	write.table(x, file=file, quote=quote, row.names=row.names, na=na, sep="\t", ...)

# Given a vector, matrix, or data frame "x", return a matrix (or data frame if "x" is already a data frame, unless "make.matrix" is TRUE) with valid row and column names.
dimformat <- function(x, make.matrix=FALSE, rowbase="row", colbase="col")
{
	if(!isMDF(x)) x = as.matrix(x)
	if(is.null(rownames(x))) {
		if(nrow(x)==1)
			rownames(x) = rowbase
		else
			rownames(x) = paste(rowbase, seq(nrow(x)), sep="")
	}
	if(is.null(colnames(x))) {
		if(ncol(x)==1)
			colnames(x) = colbase
		else
			colnames(x) = paste(colbase, seq(ncol(x)), sep="")
	}
	if(make.matrix && !is.matrix(x)) x = asmatattr(x)
	return(x)
}

# Evaluate parsable text, e.g., evpat("c(1, 2, 3)") + 1 = c(2, 3, 4).
evpat <- function(x) eval(parse(text=x))

# Given an object `x`, add the class(es) in `extra` to it as an attribute ("extra.class") and attached (leading by default, if "first" is TRUE) to its class string.
extra.class <- function(x, extra=attr(x, "extra.class"), first=TRUE)
{
	if(first) {
		attr(x, "extra.class") = union(extra, attr(x, "extra.class"))
		class(x) = union(attr(x, "extra.class"), class(x))
	} else {
		attr(x, "extra.class") = union(attr(x, "extra.class"), extra)
		class(x) = union(class(x), attr(x, "extra.class"))
	}
	return(x)
}

# Wrapper for dplyr::filter() that preserves row names and attributes.
filter_with_attributes <- function(x, ...)
{
	stopifnot(is.data.frame(x))
	
	if("rownames_preservation_column" %in% names(x))
		stop("'names(x)' cannot contain 'rownames_preservation_column'")
	x$rownames_preservation_column = rownames(x)
	y = filter(x, ...)
	
	rownames(y) = y$rownames_preservation_column
	y$rownames_preservation_column = NULL
	y = copyattr(y, x)
	class(y) = class(x)
	attr(y, "extra.class") = attr(x, "extra.class")
	
	return(y)
}

# Convenience function for getting first element of a list or vector, while accepting additional (ignored) arguments.  Useful for passing to aggregation functions.  NOTE:  this function was previously defined here as below, but `dplyr` contains a `first` function that does exactly the same thing with better checking, so we can just use that.  The function definition here is retained in case it's ever useful (DD 2018-04-10).
#first <- function(x, ...) if(length(x)) x[[1]] else 0

# Given 2x2 contingency table cells `n11`, `n12`, `n21`, and `n22` for fisher_test_counts_one_sided_pvalue(); or Boolean (logical) vectors, matrices or data frames `x` and `y` for fisher_test_logical_one_sided_pvalue(); return p-value(s) for a one-sided test of Fisher's exact test hypothesis of association between them.  Equivalent to `fisher.test(x, y, alternative='greater')$p.value` but much faster.
fisher_test_counts_one_sided_pvalue <- function(n11, n12, n21, n22)
{	
	q = n11 # white balls drawn
	m = n11 + n12 # white balls in urn
	n = n21 + n22 # black balls in urn
	k = n11 + n21 # balls drawn
	
	phyper(q-1, m, n, k, lower.tail=FALSE)
		# Note the `q-1` which effectively represents a degrees-of-freedom adjustment for fixing the margin totals; see <http://r.789695.n4.nabble.com/hypergeometric-vs-fisher-test-td2324223.html> and calls to phyper() in the code for fisher.test().  In the code for fisher.test(), this is rendered as `q - or` where `or` is the "hypothesized odds ratio," 1 by default; it is passed as a noncentrality parameter.  Presumably we could thus make its value adjustable to test against the hypothesis of other odds ratios, but honestly, why would we want to do that?
}
fisher_test_logical_one_sided_pvalue <- function(x, y,
	simplify=FALSE, extended=TRUE)
{
	if(is.data.frame(x))
		x = as.matrix(x)
	else if(!isMDF(x)) {
		name = deparse(substitute(x))
		x = as.matrix(x)
		colnames(x) = name
	}
	if(is.data.frame(y))
		y = as.matrix(y)
	else if(!isMDF(y)) {
		name = deparse(substitute(y))
		y = as.matrix(y)
		colnames(y) = name
	}

	.x = !x
	.y = !y

	n11 = crossprod( x ,  y)
	n12 = crossprod( x , .y)
	n21 = crossprod(.x ,  y)
	n22 = crossprod(.x , .y)
	
	retn = fisher_test_counts_one_sided_pvalue(n11, n12, n21, n22)
	if(simplify) retn = drop(retn)
	attr(retn, "expected") = outer(colMeans(x), colSums(y))
	attr(retn, "observed") = n11
	
	return(retn)
}

# Flexible version of correlation function that can accept the extra arguments to the chosen methods.  If `method="pearson"` and `ranked=TRUE` then this is equivalent to Spearman correlation.
flexcor <- function(x, y=x, method=c("pearson", "lorenz"), cosine=FALSE, 
	drop=FALSE, group=NULL, use=c("all.obs", "pairwise.complete.obs"), ranked=FALSE, ...)
{
	method = match.arg(method)
	use = match.arg(use)
	if(ranked) {
		x = apply(as.matrix(x), 2, rank)
		y = apply(as.matrix(y), 2, rank)
	}
	retn = switch(method,
		pearson = if(cosine)
			coscor(x, y, use=use, ...)
		else
			cor(x, y, use=use, ...),
		lorenz = lorcor(x, y, cosine=cosine, group=group, use=use, ...)
	)
	if(drop) retn = drop(retn)
	retn[retn > 1] = 1 # deal with instability
	retn[retn < -1] = -1
	return(retn)
}

# Functions to perform matrix-multiplication-style operations on the rows and columns of vectors, matrices, or data frames with arbitrary functionals (functions that take vector arguments and return scalar results).  Arguments "x" and "y" are the vectors, matrices, or data frames, subject to dimensional requirements for matrix mutiplication (functional_matrix_multiply()) or cross product (functional_matrix_crossprod() and functional_matrix_tcrossprod()).  Argument "f" is a functional that takes two vector arguments of equal length and returns a scalar.  Arguments in "..." are optional extra arguments to "f".  Note that because of how`fnl_default` is defined, `functional_matrix_multiply(x, y)` is equivalent to `x %*% y`, `functional_matrix_crossprod(x, y)` is equivalent to `crossprod(x, y)`, and `functional_matrix_tcrossprod(x, y)` is equivalent to `tcrossprod(x, y)`; using the functions in this manner is horribly inefficient compared to the base R functions, and is allowed only for pedagogical purposes.
fnl_default <- function(a, b) sum(a*b)
functional_matrix_multiply <- function(x, y=t(x), f=fnl_default, ...)
{
	x = as.matrix(x)
	y = as.matrix(y)
	stopifnot(ncol(x)==nrow(y))
	retn = msapply(1:ncol(y), function(j)
	           sapply(1:nrow(x), function(i)
	               f(x[i,], y[,j], ...)))
	if(!is.matrix(retn)) retn = matrix(retn, nrow=nrow(x))
		# the results of "msapply(sapply(...))" can be reduced to a vector if x or y is a single-column matrix, so the call to "matrix(...)" fixes that
	rownames(retn) = rownames(x)
	colnames(retn) = colnames(y)
	return(retn)
}
functional_matrix_crossprod <- function(x, y=x, f=fnl_default, ...)
	functional_matrix_multiply(x=t(x), y=y, f=f, ...)
functional_matrix_tcrossprod <- function(x, y=x, f=fnl_default, ...)
	functional_matrix_multiply(x=x, y=t(y), f=f, ...)

# Interleave vectors, or columns of data frames or matrices.  See <https://stat.ethz.ch/pipermail/r-help/2006-March/101023.html>.
general_interleave_list <- function(x)
{
	if(!is.list(x))
		stop("'x' must be a list")
	
	if(isMDF(x[[1]])) {
		nr = sapply(x, nrow)
		if(var(nr) > 0)
			stop("unequal numbers of rows in matrix/d.f. elements of 'x'")
		ns = sapply(x, ncol)
	} else ns = sapply(x, length)
	
	nx = length(x)
	ord = order(unlist(lapply(1:nx, function(i) nx * (1:ns[i]) + i)))
		# create and concatenate vectors of "ranks", i.e. numbers indicating how far down the interleaved list each element should go, then get their order
	
	if(isMDF(x[[1]])) {
		x = Reduce(cbind, x)
		x[, ord]
	} else {
		x = Reduce(c, x)
		x[ord]
	}
}
general_interleave <- function(...) general_interleave_list(list(...))

# Given a matrix or data frame `x` representing numeric values corresponding to the (named) rows and columns of `x`, draw a heatmap plot of height `height` and optionally save it to file `file`.  Argument `xcell` gives the values to be shown in the cells (if `show_value` is TRUE).  Arguments `cut` and `separation` are as to vec2plotcol().  If `adjcut` is TRUE, then `cut` will be adjusted based on the data in an effort to prevent values close to `cut` from taking on inappropriate hues.  Argument `limit` is the minimum absolute value of the range of numbers to be usable on the plot, with limits otherwise being drawn from data; `minlimit` and `maxlimit` give finer-grained control.  If limits are NULL, then all ranges will be drawn from the data.  If `symmetric` is true, limits will be symmetrized (color assigments should be symmetric in all cases).  Argument `color_bar_height` gives an optional scaling factor for the placement of the color scale, and `color_bar_name` gives the name to use for the color bar.  If `show_value` is TRUE, values will be printed on the heatmap cells, with `cellval_round` giving the number of digits to round to.  Argument `text_size` gives a default size for the entire plot, with `*_text_size` giving control over text for various elements.  Arguments `height`, `width`, and `file` refer to the Cairo graphics device used for the plot.
setMethodS3("ggheatmap", "default",
function(x, xcell=x, cut=0, separation=0.2, adjcut=FALSE, limit=1, 
	symmetric=TRUE, minlimit=NULL, maxlimit=NULL, color_bar_height=NULL, color_bar_name="value", show_value=FALSE, value_color=NULL, value_color_type=c("white", "black", "flip"), cellval_round=3, text_size=12, x_axis_text_size=text_size, y_axis_text_size=text_size, value_text_size=text_size/4, scalecut=FALSE, center_colors=FALSE, color_center=NULL, break_above_pattern=NULL, break_above_lines=NULL, main=NULL, main_text_size=1.2*text_size, caption=NULL, caption_text_size=0.9*text_size, subtitle=NULL, subtitle_text_size=text_size, height=7, width=8, file=NULL, open.file=TRUE, ...)
{
	# check package availability
	if(!require(ggplot2)) stop("library 'ggplot2' not available")
	if(!require(grid)) stop("library 'grid' not available")
	
	# other sanity checks
	if(is.null(rownames(x)))
		stop("'x' must have non-NULL rownames")
	if(is.null(colnames(x)))
		stop("'x' must have non-NULL colnames")
	if(is.null(rownames(xcell)))
		stop("'xcell' must have non-NULL rownames")
	if(is.null(colnames(xcell)))
		stop("'xcell' must have non-NULL colnames")
	stopifnot(nrow(x) == nrow(xcell))
	stopifnot(ncol(x) == ncol(xcell))
	stopifnot(all.equal(rownames(x), rownames(xcell)))
	stopifnot(all.equal(colnames(x), colnames(xcell)))
	if(!is.null(limit) && (limit <= 0))
		stop("'limit' must be positive or NULL; try 'minlimit' and 'maxlimit'")
	if(!is.null(minlimit) && !is.null(maxlimit)) if(minlimit >= maxlimit)
		stop("non-NULL 'minlimit' must be less than non-NULL 'maxlimit'")

	# prep data
	xmelt = reshape2::melt(as.matrix(x), as.is=TRUE)
	names(xmelt) = c("row", "col", "val")
	xmelt$cell = xcell[as.matrix(xmelt[1:2])]
	xmelt$col = factor(xmelt$col, levels=colnames(x))
		# keep columns in order on plot
	xmelt$row = factor(xmelt$row, levels=rev(rownames(x)))
		# keep rows in order on plot; "rev" since geom_tile seems to like putting things bottom to top, and we want the rows of x to appear top to bottom as they do in x itself
	invisible(gc())
	
	# get cell fill colors
	val = NULL # suppress "no visible binding"
	valrange = range(xmelt$val[is.finite(xmelt$val)], na.rm=TRUE)
	if(!is.null(limit)) {
		if(symmetric) valrange[1] = min(-limit, valrange[1])
		valrange[2] = max(limit, valrange[2])
	}
	if(!is.null(minlimit)) {
		valrange[1] = minlimit # min(minlimit, valrange[1])
		xmelt$val[na.sub(xmelt$val) < minlimit] = minlimit
	}
	if(!is.null(maxlimit)) {
		valrange[2] = maxlimit # max(maxlimit, valrange[2])
		xmelt$val[na.sub(xmelt$val) > maxlimit] = maxlimit
	}
	if(symmetric) {
		limit = max(abs(valrange))
		valrange = c(-limit, limit)
	}
	colseq = seq(valrange[1], valrange[2], length.out=1001)
	if(adjcut) {
		abval = abs(xmelt$val)
		loval = abval[abval < cut]
		hival = abval[abval >= cut]
		if(length(loval) && length(hival))
			cut = (max(loval) + min(hival)) / 2
	}
	if(center_colors) {
		if(is.null(color_center))
			mu = mean(xmelt$val)
		else
			mu = color_center
	} else mu = 0
	colors = vec2plotcol(colseq-mu, cut=cut-mu, separation=separation)$hex
	
	# build the basics of the heatmap; the following largely comes from <http://is-r.tumblr.com/post/32387034930/simplest-possible-heatmap-with-ggplot2>
	gg = ggplot(xmelt, aes(y=row, x=col, fill=val)) # create data structure
	gg = gg + geom_tile() # specify we are building a heatmap
	if(show_value) {
		
		if(is.null(value_color)) {
		value_color_type = match.arg(value_color_type)
			if(value_color_type=="flip") {
				# find colors representing closest matches to values, then flip to give maximum contrast to cell text
				delta = na.sub(outer(xmelt$val, colseq, "-"))^2
				cell_fill_color = colors[apply(delta, 1, which.min)]
				value_color = hex_contrast(cell_fill_color)
				value_color[value_color=="#DDDDDD"] = "#000000"
					# NAs in `xmelt$val` can produce gray (#DDDDDD) fill color, so change those to black
			} else value_color = value_color_type
		} else value_color = rep(value_color, length.out=length(xmelt$val))
		
		if(is.numeric(xmelt$cell)) {
			cellval_fmt = paste("%.", cellval_round, "f", sep="")
			label = sprintf(cellval_fmt, xmelt$cell)
		} else label = paste(xmelt$cell) # paste(...) changes NA to "NA"
		
		gg = gg + geom_text(aes(label=label), size=value_text_size, 
			color=value_color) # add cell labels; see <http://stackoverflow.com/questions/14290364/heatmap-with-values-ggplot2>	
	}
	gg = gg + theme(
		axis.title = element_blank(), # suppress x and y axis labels
		axis.ticks = element_blank(), # suppress axis tick marks
		text = element_text(size=text_size),
			# make text larger and easier to read
        axis.text.x = element_text(size=x_axis_text_size,
        	angle=45, hjust=1, vjust=1),
        		# angle x-axis text and justify to bottom of heatmap
        axis.text.y = element_text(size=y_axis_text_size)
	)
	invisible(gc())
	
	# fill cells with preferred colors and make color bar
	gg = gg + scale_fill_gradientn(colors=colors, name=color_bar_name,
		na.value=NEUTRAL_COLORS["gray", "hex"], limits=range(colseq),
		guide=guide_colorbar(barheight=color_bar_height, ticks=FALSE))
	
	# fill whole plot area and cover background gray grid
	gg = gg + scale_x_discrete(expand = c(0, 0))
	gg = gg + scale_y_discrete(expand = c(0, 0))
	
	# add line breaks PRN; see <http://stackoverflow.com/questions/29724011/how-to-add-dark-lines-to-heat-map-plot>
	if(!is.null(break_above_lines)) {
		linedata = data.frame(x    = 0.5,
							  xend = ncol(x) + 0.5,
							  y    = break_above_lines - 0.5,
							  yend = break_above_lines - 0.5)
			# "- 0.5" instead of "+ 0.5" because lines are 0-indexed in ggplot, but break_above_lines uses the indexing of "line 1, line 2, ..."
		xend = y = yend = NULL # suppress "no visible binding"
		gg = gg + geom_segment(data=linedata, inherit.aes=FALSE, size=0.3,
					aes(x=x, xend=xend, y=y, yend=yend))
	}
	
	# add main and subtext
	if(!is.null(main)) main = str_wrap(main)
	if(!is.null(caption)) caption = paste("\n", str_wrap(caption), sep="")
	gg = gg + labs(title=main, subtitle=subtitle, caption=caption)
	gg = gg + theme( # `hjust` is 0 for left, 0.5 for center, 1 for right
		plot.title=element_text(hjust=0.5, size=main_text_size),
		plot.subtitle=element_text(hjust=0.5, vjust=1, size=subtitle_text_size),
		plot.caption=element_text(hjust=0.5, vjust=1, size=caption_text_size))
	
	# plot the heatmap
	#if(is.null(file)) file = tempfile(fileext=".eps")
	#cairo_ps(filename=file, height=height, width=width)
	if(is.null(file)) file = tempfile(fileext=".png")
	png(filename=file, height=height, width=width, units="in", res=300)
	grid.draw(gg)
	dev.off()
	if(open.file) system(paste("open", gsub(" ", "\\\\ ", file)))
		# the above gsub(...) syntax properly escapes spaces in file names
	return(file)

}, conflict="quiet")

# `ggheatmap` method for objects of class "group_enrichment"
setMethodS3("ggheatmap", "group_enrichment",
function(u, cellval=c("nfold", "qscore", "foldenrich", "pcenrich", "nxy"),
            scaleval=c("foldenrich", "qscore", "pcenrich", "nxy"),
            cut="qscore", separation=0.2,
            fdrcut=FDR_LOW, data_axis=c("rows", "cols"),
            symmetric=FALSE, non_sig_gray=TRUE, oneline=FALSE,
            break_above_pattern=NULL, break_above_lines=NULL,
            first_row_gray=attr(u, "xaugment"),
            first_col_gray=attr(u, "yaugment"),
            value_color_type=c("std", "white", "black", "flip"),
            two.sided=attr(u, "two.sided"), ...)
{
	# check package availability
	if(!require(ggplot2)) stop("library 'ggplot2' not available")
	if(!require(grid)) stop("library 'grid' not available")
	
	# process arguments
	scaleval = match.arg(scaleval)
	cellval = match.arg(cellval)
	data_axis = match.arg(data_axis)
	color_bar_name = switch(scaleval, qscore="q-score",
		foldenrich="fold enrich", pcenrich="enrich %", nxy="n")
	cellval_round = switch(cellval, nxy=0, foldenrich=2, pcenrich=1, qscore=3)
	first_row_gray = first_row_gray ; first_col_gray = first_col_gray
		# due to lazy evaluation, with the default "first_*_gray=attr(u, ...)" values we have to extract these here before manipulating u
	
	# make cell value calculations and format for display
	qscore = -log10(u$qval)
	qscore[is.infinite(qscore)] = PVALADJ_PRECISION + 1
		# -log10(q-scaleval = 0) --> max -log10(nonzero q-qvalue) + 1
	if(is.null(two.sided)) # assume `two.sided` is FALSE
		u$qscore = qscore * sign(u$foldenrich)
	else if(two.sided) # allow positive and negative values
		u$qscore = qscore
	else # `two.sided` is FALSE
		u$qscore = qscore * sign(u$foldenrich)
	if(cellval=="nfold") {
		sep = ifelse(oneline, " ", "\n")
		u$nfold = sprintf("%i%s(%.2f)", u$nent, sep, u$foldenrich)
		u$nfold[is.na(u$qscore)] = u$nent[is.na(u$qscore)]
			# don't report foldenrich changes in cases where there's no meaningful y, e.g. "allgenes" elements
	}
	
	# organize internal data structures
	ucols = c("x", "y", "qscore", scaleval, cellval, "augmented")
	u = unique(u[ucols])
	names(u)[4:5] = c("scaleval", "cellval")
	xlevels = unique(u$x)
	ylevels = unique(u$y)
	
	# organize data structures to pass to ggheatmap()
	qscore = acast(u, x ~ y, value.var="qscore")
	scaleval = acast(u, x ~ y, value.var="scaleval")
	cellval = acast(u, x ~ y, value.var="cellval")
	augmented = acast(u, x ~ y, value.var="augmented")
	row.order = order(factor(rownames(qscore), levels=xlevels))
	col.order = order(factor(colnames(qscore), levels=ylevels))
	qscore = qscore[row.order, col.order]
	scaleval = scaleval[row.order, col.order]
	if(first_row_gray) scaleval[1,] = 0
	if(first_col_gray) scaleval[,1] = 0
	cellval = cellval[row.order, col.order]
	augmented = augmented[row.order, col.order]
	
	# transpose ggheatmap() arguments PRN
	if(data_axis=="cols") {
		qscore = t(qscore)
		scaleval = t(scaleval)
		cellval = t(cellval)
		augmented = t(augmented)
	}
	
	# cut calculation PRN
	if(cut=="qscore") {
		aqscore = na.sub(abs(qscore), 0)
		maxscore = max(aqscore)
		if(maxscore >= -log10(fdrcut)) {
			goodval = na.omit(abs(scaleval)[aqscore >= -log10(fdrcut)])
			mingood = min(goodval)
			badval = na.omit(abs(scaleval)[aqscore < -log10(fdrcut)])
			badval = badval[badval < mingood]
			if(length(badval)==0) badval = 0
			cut = (mingood + max(badval)) / 2
		} else cut = maxscore + 10 # everything will be gray
	}
	if(non_sig_gray) scaleval = scaleval * (qscore >= -log10(fdrcut))
		# non-significant scaleval goes to 0 ==> cells go to gray
	
	# line break calculation PRN
	if(is.null(break_above_pattern)) {
		break_above_lines = break_above_lines
	} else {
		break_above_lines = grep(break_above_pattern, rev(rownames(scaleval)))
		break_above_lines = setdiff(break_above_lines, c(0, nrow(scaleval)))
		break_above_lines = break_above_lines + 1
		if(length(break_above_lines)==0) break_above_lines = NULL
	}
	
	# cell colors
	value_color_type = match.arg(value_color_type)
	if(value_color_type == "std") {
		value_color = matrix("#FFFFFF",
			nrow=nrow(augmented), ncol=ncol(augmented))
		value_color[augmented] = "#000000" # black text in marginal cells
	} else value_color = NULL
	
	# draw heatmap and return
	ggheatmap(x=scaleval, xcell=cellval, color_bar_name=color_bar_name,
		symmetric=symmetric, cut=cut, separation=separation, show_value=TRUE,
		cellval_round=cellval_round, break_above_lines=break_above_lines, 
		value_color=value_color, value_color_type=value_color_type, ...)

}, conflict="quiet")

# `ggheatmap` method for objects of class "matrix_rows_corrept"
setMethodS3("ggheatmap", "matrix_rows_corrept",
function(u, cellval=c("correl", "corct"), drop_na_corct=TRUE, cut="qval", 
	separation=0.2, fdrcut=FDR_LOW, symmetric=TRUE, oneline=FALSE, break_above_pattern=NULL, ...)
{
	# check package availability
	if(!require(ggplot2)) stop("library 'ggplot2' not available")
	if(!require(grid)) stop("library 'grid' not available")

	# process arguments
	cellval = match.arg(cellval)
	if((cellval == "corct") & !("n" %in% names(u))) {
		warning("'n' not in columns of 'u', setting cellval = 'correl'")
		cellval = "correl"
	}
	
	# format cell and scale values for display
	if(cellval=="corct") {
		sep = ifelse(oneline, " ", "\n")
		u$cellval = sprintf("%.3f%s(%i)", u$cor, sep, u$n)
		if(drop_na_corct)
			u$cellval[is.na(u$n)] = sprintf("%.3f", u$cor)[is.na(u$n)]
	} else u$cellval = sprintf("%.3f", u$cor) # cellval=="correl"
	u$scaleval = u$cor
	if(cut=="qval") {
		leqcut = (u$qval <= fdrcut)
		u$scaleval[!leqcut] = 0
		if(any(leqcut))
			scalecut = 0.999 * min(abs(u$scaleval[leqcut]))
		else scalecut = 0
	} else scalecut = cut
	
	# organize data structures to pass to ggheatmap()
	u = unique(u[c("x", "y", "cellval", "scaleval")])
	xlevels = unique(u$x)
	ylevels = unique(u$y)
	cellval = acast(u, x ~ y, value.var="cellval")
	scaleval = acast(u, x ~ y, value.var="scaleval")
	row.order = order(factor(rownames(cellval), levels=xlevels))
	col.order = order(factor(colnames(cellval), levels=ylevels))
	cellval = cellval[row.order, col.order]
	scaleval = scaleval[row.order, col.order]
	
	# line break calculation PRN
	if(is.null(break_above_pattern)) break_above_lines = NULL else {
		break_above_lines = grep(break_above_pattern, rownames(scaleval))
		break_above_lines = setdiff(break_above_lines, 1)
		if(length(break_above_lines)==0) break_above_lines = NULL
	}
	
	# draw heatmap and return
	ggheatmap(x=scaleval, xcell=cellval, color_bar_name="cor",
		symmetric=symmetric, cut=scalecut, separation=separation, show_value=TRUE, break_above_lines=break_above_lines, ...)

}, conflict="quiet")

# Extension of `gsub` that allows for multiple replacements (thus the "mr" in the name) i.e. `replacement` may be a vector as opposed to a single string.  Arguments `pattern`, `x`, and `...` are passed as-is to `grepl` and `gsub`.  Argument `split` is passed to `strsplit` and should be a character which is _not_ present in any of the elements of `pattern`, `replacement`, or `x`; if present, a warning will be raised, but the return value will still split on it.  In the function's current form, `x` should only be a vector of strings; using it on data frames etc. will destroy the structure.  From PKumar's answer at <https://stackoverflow.com/questions/48768173/replace-one-element-in-vector-with-multiple-elements>.  
gmrsub <- function(pattern, replacement, x, split=" ", ...)
{
	if(any(grepl(split, pattern, ...)))
		warning("`split` present in `pattern`")
	if(any(grepl(split, replacement, ...)))
		warning("`split` present in `replacement`")
	if(any(grepl(split, x, ...)))
		warning("`split` present in `x`")
	replacement = paste(replacement, collapse=split)
	unlist(strsplit(gsub(pattern, replacement, x, ...), split=split))
}

# Given design matrices or vectors of factors (or types that can be interpreted as factors) "x" and "y", perform a test for enrichment of certain combinations of x and y.  Arguments "xlevels" and "ylevels" give the levels of "x" and "y" as factors to be used in the contingency table; it is useful to set these by hand if not all possible levels are represented in the data.  If "permute" is TRUE, a permutation test will be used, otherwise a hypergeometric test.  Argument "maxp" is the maximum number of permutations to use in the test.  If the number of possible permutations is > "maxp", random draws of permutations will be used; "seed" is the seed for random draw, and if seed <= 0, no seed will be set and results may be inconsistent across multiple runs.  Neither "maxp" nor "seed" have any effect if "permute" is FALSE.  If "two.sided" is TRUE, a two-sided enrichment test is performed, otherwise the test is one-sided with over-enrichment as the alternative hypothesis.  Argument "entity_names" gives the names of the entities (e.g. genes) in the rows of "x" and "y"; normally these will be unique, but if they are not, then the "ecounts" column of the return value will contain the number of _unique_ entities in each group or combination, and (if "entities" is TRUE) the "entities" column of the return value will similarly contain the names of the unique entities in each group or combination.  Note that "entity_names" is NULL by default in the function signature, but if NULL it will be assigned the value of "rownames(x)" during function execution.
# TO DO:  update documentation based on the following "OLD" sections (DD 2016-05-16).
# <OLD permutation_enrichment() documentation>
# Further arguments and return value are similar to group_enrichment(), with "x" corresponding to "data" and "y" corresponding to "test", with the following exceptions:  return elements "ny", "pcy", and "pcygx" have no equivalents in the return elements of group_enrichment(), while "nxy" corresponds to "ntest" and "pcxy" corresponds to "pctest".
# </OLD permutation_enrichment() documentation>
# <OLD group_enrichment() documentation>
# Calculate enrichment of "data" groups in "test" statuses, where "data" is a N x G matrix or data frame with entities (e.g. genes) in the rows and groups (e.g. modules) in the columns, and "test" is a N x S matrix or data frame with entities in the rows and statuses (e.g. list status or miRNA target status) in the columns.  The (n,g)th element of data should be TRUE or 1 if the nth element is a member of the gth group, FALSE or 0 otherwise.  The (n,s)th element of test should be TRUE or 1 if the nth entity has the sth status, FALSE or 0 otherwise.  If "two.sided" is TRUE, two-sided p-values will be calculated, otherwise one-sided p-values for positive enrichment.  If "entities" is TRUE, names of entities for which both group and status are TRUE/1 will be included in the return value; if "entities" is TRUE but row names of "data" are NULL, an error will result.  If "drop_cross" is TRUE, comparisons of "data" groups matching the names of "test" statuses will be dropped to prevent inappropriate comparisons of groups to each other.  If "drop_grep" is TRUE when "drop_cross" is TRUE (no effect if "drop_cross" is FALSE) then comparisons of "data" groups _partially matching_ the names of "test" statuses will be dropped; care must be taken with the naming schemes in this case.  If "augment" is TRUE, then lines of the return data frame with data = "alldata" give counts and percentages (with NA p- and q-values) for "data" as a whole, and similarly, lines with test = "alltest" for "test" as a whole.  If "individual_fdr" is TRUE, then FDRs (q-values) will be calculated separately for each status in "test".  The "method" argument gives the method used for FDR correction.  Return value is a data frame with columns:
# - data:      the data group, i.e. one of the columns of "data"
# - test:      the test status, i.e. one of the columns of "test"
# - enrich:    enrichment percentage of the group in the status
# - fold:      fold enrichment of the group in the status
# - pval:      p-value for enrichment of the the group in the status
# - qval:      q-value for enrichment of the the group in the status
# - ndata:     number of entities in the group
# - pcdata:    percentage of entities in the group
# - ntest:     number of entities having the status that are in the group
# - pctest:    percentage of entities having the status that are in the group
# - entities:  if argument "entities" is TRUE, names of entities having the 
#              status in the group, separated by "%%"
# Probabilistically, where G is the event of being in a particular group, S is the event of having a particular status, Pr(.) gives the probability of an event, and R = Pr(G|S) / Pr(G) = Pr(G,S) / [Pr(G) Pr(S)]:
# - pcdata = 100 Pr(G)
# - pctest = 100 Pr(G|S)
# - enrich = 100 {[Pr(G|S) - Pr(G)] / Pr(G)}
#          = 100 {Pr(G|S)/Pr(G) - 1}
#          = 100 {Pr(G,S)/[Pr(G)Pr(S)] - 1}
#          = 100 {R - 1}
# - fold   = {R, R >= 1 ; -1/R, 0 < R < 1; 0, R=0}
# </OLD group_enrichment() documentation>
group_enrichment <- function(x, y, xlevels=NULL, ylevels=NULL,
	permute=FALSE, maxp=10000, seed=123, two.sided=FALSE, entity_names=NULL, entities=TRUE, drop_cross=TRUE, drop_grep=FALSE, augment=TRUE, xaugment=augment, yaugment=augment, individual_fdr=FALSE, method="BH", ...)
{
	# munge "x" as needed and do sanity checks
	if(!isMDF(x)) {
		xnames = names(x)
		x = categorical_design_matrix(x)
		rownames(x) = xnames
	}
	if(!is.matrix(x)) x = as.matrix(x)
		# x may be a data frame or Matrix object, so make it a regular matrix
	if(xaugment) x = cbind(xall=1, x)
	n = nrow(x)
	if(is.null(rownames(x)))
		rownames(x) = paste("entity", 1:n, sep="")
	if(is.null(xlevels)) xlevels = colnames(x) else {
		if(xaugment) xlevels = union("xall", xlevels)
		stopifnot(all(colnames(x) %in% xlevels))
		x = x[, order(factor(colnames(x), levels=xlevels)), drop=FALSE]
	}
	if(is.null(entity_names)) entity_names = rownames(x) else 
		stopifnot(length(entity_names)==n)
	
	# munge "y" as needed and do sanity checks
	if(!isMDF(y)) {
		ynames = names(y)
		y = categorical_design_matrix(y)
		rownames(y) = ynames
	}
	if(!is.matrix(y)) y = as.matrix(y)
		# y may be a data frame or Matrix object, so make it a regular matrix
	if(yaugment) y = cbind(yall=1, y)
	stopifnot(n==nrow(y))
	if(is.null(rownames(y))) rownames(y) = rownames(x) else 
		stopifnot(isTRUE(all.equal(rownames(x), rownames(y))))
	if(is.null(ylevels)) ylevels = colnames(y) else {
		if(yaugment) ylevels = union("yall", ylevels)
		stopifnot(all(colnames(y) %in% ylevels))
		y = y[, order(factor(colnames(y), levels=ylevels)), drop=FALSE]
	} 
		
	# tables of observed and expected combination counts
	observed = crossprod(x, y)
	xcounts = colSums(x)
	ycounts = colSums(y)
	expected = tcrossprod(xcounts, ycounts) / n
	dimnames(expected) = dimnames(observed)
	
	# tables of observed entities and counts thereof (expectation for entity counts is not currently defined) and if necessary, collapsed entity lists
	observed_entity_counts = functional_matrix_crossprod(x, y,
		function(a, b) length(unique(entity_names[a & b])))
	if(entities) observed_entity_lists = functional_matrix_crossprod(x, y,
		function(a, b) paste(unique(entity_names[a & b]), collapse="%%"))
	
	# calculate enrichment and foldenrich change
	ratio = na.sub(observed / expected, NA)
		# change 0/0 NaN values to NA for consistency
	pcenrich = 100 * (ratio - 1)
	foldenrich = ratio
	negidx = na.sub((0 < foldenrich) & (foldenrich < 1))
	foldenrich[negidx] = -1 / foldenrich[negidx]
	zeroidx = na.sub(foldenrich == 0)
	foldenrich[zeroidx] = 0
	
	# calculate p-values and adjust as needed for augmentation
	if(permute) {
		# sample and form tables of expected combinations, calculate upper p-value as the standard p-value, if necessary calculate lower p-value for two-sided test, then calculate final p-value
		perms = sample_permutations(n, maxp, seed)
		sample_res = mlapply(perms, function(perm)
			crossprod(x, y[perm, , drop=FALSE]))
		pval = list_mean(mlapply(sample_res, function(r) r >= observed))
		if(two.sided) {
			lpval = list_mean(mlapply(sample_res, function(r) r <= observed))
			pval = 2 * pmin(pval, lpval)
				# converts one-sided to two-sided p-value
		}
	} else {
		pval = fisher_test_logical_one_sided_pvalue(x, y)
		if(two.sided) pval = 2 * pmin(pval, 1-pval)
			# converts one-sided to two-sided p-value
	}
	if(xaugment) pval["xall", ] = NA
	if(yaugment) pval[, "yall"] = NA
	
	# build return data frame
	idx = as.matrix(list_grid(list(x=xlevels, y=ylevels)))
	retn = data.frame(idx, pcenrich=pcenrich[idx],
		foldenrich=foldenrich[idx], pval=pval[idx])
	if(drop_cross) {
		if(drop_grep) for(ylevel in ylevels)
			retn = subset(retn, !(grepl(ylevel, x) & grepl(ylevel, y)))
		else retn = subset(retn, x != y)
	}
	retn$qval = NA # will calculate later, but put in place here
	idx = as.matrix(retn[,1:2])
	retn$nent = observed_entity_counts[idx]
	retn$nx = xcounts[retn$x]
	retn$pcx = 100 * retn$nx / n
	retn$ny = ycounts[retn$y]
	retn$pcy = 100 * retn$ny / n
	retn$nxy = observed[idx]
	retn$pcxy = 100 * retn$nxy / n
	retn$pcxgy = 100 * retn$nxy / retn$ny
	retn$pcygx = 100 * retn$nxy / retn$nx
	if(entities) retn$entities = observed_entity_lists[idx]
	rownames(retn) = paste(retn$x, retn$y, sep="_")
	
	# make sure all 0-count enrichments and p-values and enrichments are NA, then calculate FDR (q-values)
	retn[retn$nxy == 0, c("pcenrich", "foldenrich", "pval")] = NA
	if(individual_fdr) {
		for(ylevel in ylevels)
		{
			isy = (retn$y == ylevel)
			retn$qval[isy] = pvaladj(retn$pval[isy], method=method, ...)
		}
	} else retn$qval = pvaladj(retn$pval, method=method, ...)
	
	# record augmented status
	retn$augmented = FALSE
	retn$augmented[retn$x == "xall"] = TRUE
	retn$augmented[retn$y == "yall"] = TRUE
	
	# package it up, send it back
	attr(retn, "xaugment") = xaugment
	attr(retn, "yaugment") = yaugment
	attr(retn, "two.sided") = two.sided
	extra.class(retn, "group_enrichment")
}
setMethodS3("subset", "group_enrichment", function(x, ...)
	copyattr(subset.data.frame(x, ...), x), conflict="quiet")

# In-place string substitution on a text file.  Arguments `warn` and `...` are passed to readLines().  See <https://gist.github.com/mages/1544009>.
gsub_file <- function(pattern, replacement, file, ignore.case=FALSE,
	perl=FALSE, fixed=FALSE, useBytes=FALSE, warn=FALSE, ...)
{
	x = readLines(file, warn=warn, ...)
	x = gsub(pattern, replacement, x, ignore.case=ignore.case,
		     perl=perl, fixed=fixed, useBytes=useBytes)
	cat(x, file=file, sep="\n")
}

# Given lists or data frames `x` and `y`, insert `y` after the named `after` element/column of `x`.  By default, `after` is the first name of `x`, i.e. `y` will be inserted after the first element/column of `x`.  If `x` is a data frame, `y` must be a data frame with the same number of rows as `x`, or a list of vectors of which every member has the same number of elements as the rows of `x`.  The names of `x` and the names of `y` must be disjoint sets.
insert_after <- function(x, y, after=names(x)[1])
{
	# initial sanity checking and data munging; note `is.list` returns TRUE for data frames as well, so the initial list check is fine for data frames
	stopifnot(is.list(x))
	stopifnot(is.list(y))
	if(is.null(names(x))) names(x) = paste(
		deparse(substitute(x)), 1:length(x), sep="")
	if(is.null(names(y))) names(y) = paste(
		deparse(substitute(y)), 1:length(y), sep="")
	stopifnot(length(intersect(names(x), names(y)))==0)
	isdf = is.data.frame(x)
	if(isdf) {
		y = as.data.frame(y)
		stopifnot(nrow(x)==nrow(y))
	} else if(is.data.frame(y)) y = as.list(y)
	if(is.null(after)) after = names(x)[1]
	stopifnot(after %in% names(x))
	
	# merge, organize, and return
	retn = if(isdf) cbind(x, y) else c(x, y)
	afteridx = match(after, names(x))
	x1names = names(x)[1:afteridx]
	n = length(x)
	x2names = if(afteridx < n) names(x)[(afteridx+1):n] else character(0)
	retn[c(x1names, names(y), x2names)]
}

# Return TRUE if `x` is a matrix or a data frame, otherwise FALSE
isMDF <- function(x) (is.matrix(x) || is.data.frame(x) || is(x, "Matrix"))

# Given two vectors `x` and `y`, return TRUE if `x` is a subset of `y`, otherwise FALSE.  If `proper` is TRUE, then `x` must be a _proper_ subset of `y`, i.e. `y` must contain at least one element not in `x`.
is_subset <- function(x, y, proper=FALSE)
{
	i = length(setdiff(x, y))
	j = length(setdiff(y, x))
	retn = (i == 0)
	if(proper) retn = retn && (j > 0)
	return(retn)
}

# Perform the Jarque-Bera test for normality on numeric vector `x`.  Taken verbatim from tseries::jarque.bera.test(), for which see further documentation.
jarque.bera.test <- function (x) 
{
	if (NCOL(x) > 1) 
		stop("x is not a vector or univariate time series")
	if (any(is.na(x))) 
		stop("NAs in x")
	DNAME <- deparse(substitute(x))
	n <- length(x)
	m1 <- sum(x)/n
	m2 <- sum((x - m1)^2)/n
	m3 <- sum((x - m1)^3)/n
	m4 <- sum((x - m1)^4)/n
	b1 <- (m3/m2^(3/2))^2
	b2 <- (m4/m2^2)
	STATISTIC <- n * b1/6 + n * (b2 - 3)^2/24
	names(STATISTIC) <- "X-squared"
	PARAMETER <- 2
	names(PARAMETER) <- "df"
	PVAL <- 1 - pchisq(STATISTIC, df = 2)
	METHOD <- "Jarque Bera Test"
	structure(list(statistic = STATISTIC, parameter = PARAMETER, 
			p.value = PVAL, method = METHOD, data.name = DNAME), 
		class = "htest")
}

# Replacement for expand.grid so the last factor, rather than the first, varies fastest; `x` must be a list, or something convertible to a list.
list_grid <- function(x, KEEP.OUT.ATTRS=TRUE, stringsAsFactors=FALSE)
	rev(expand.grid(rev(as.list(x)), KEEP.OUT.ATTRS=KEEP.OUT.ATTRS, 
		stringsAsFactors=stringsAsFactors))

# Summary functions for numeric lists.
list_sum <- function(x) Reduce("+", x)
list_mean <- function(x, w=NULL)
{
	if(is.null(w))
		list_sum(x) / length(x)
	else if(!is.numeric(w))
		stop("'w' must be numeric or NULL")
	else {
		w = rep(w, length.out=length(x))
		list_sum(mapply("*", w, x, SIMPLIFY=FALSE)) / sum(w)
	}
}

# `list2dict`:  take a named list `x` and return a named vector in which names correspond to keys of the list, and elements correspond to values.  In the case of multiple values per key, only one value per key is returned.  The `use.numeric` parameter controls how values are sorted:  if `use.numeric = TRUE`, then values within multi-value keys will be sorted numerically; if `use.numeric = FALSE`, then alphabetically.  In either case, only the first value for each key will be returned. 
list2dict <- function(x, use.numeric=FALSE)
{
	stopifnot(is.list(x))
	if(is.null(names(x))) stop("`names(x)` cannot be NULL")
	sortfn <- if(use.numeric)
		function(y) as.character(sort(as.numeric(y)))
	else
		function(y) sort(y)
	msapply(x, function(y) dplyr::first(sortfn(y)))
}
		
# It is fairly common to get a result that looks like a matrix of scalars, but is actually a matrix of lists.  This solves that problem by turning `x` into a "flat" matrix in which every element is a scalar.  See user "andrewj"'s answer at <http://stackoverflow.com/questions/1515193/converting-a-matrix-of-lists-to-a-regular-matrix>.
listmatrix2flatmatrix <- function(x)
	matrix(unlist(x), ncol=ncol(x), dimnames=dimnames(x))


# extract logical columns from data frame
logicols <- function(x)
{
	stopifnot(is.data.frame(x))
	x[sapply(x, is.logical)]
}

# Calculate multivariate Lorenz correlation with cosine correlation option.  Based on pearson.clust() in MarginalCorrelationFunctions.R (Lorenz).  See Section 2.2 of "Marginal association measures for clustered data" (Lorenz et al.) for explanation of terms.  Note that "group" is used here instead of "cluster" to avoid confusion with other functions (e.g. WGCNA functions) that use the "cluster" argument to denote clusters _to which genes are assigned_ rather than groups _from which samples originate_.  If "group" is NULL, then this reduces to Pearson correlation.
lorcor <- function(x, y=x, group=NULL, cosine=FALSE, drop=FALSE,
	use=c("all.obs", "pairwise.complete.obs"))
{	
	# sanity checking and data munging
	if(!is.matrix(x)) x = as.matrix(x)
	if(!is.matrix(y)) y = as.matrix(y)
	if(nrow(x) != nrow(y))
		stop("'x' and 'y' have unequal numbers of rows")
	if(is.null(group)) group = rep(1, nrow(x))
	group = as.character(group)
	if(nrow(x) != length(group))
		stop("'length(group)' does not equal 'nrow(x)'")
	
	# deal with NAs as needed
	use = match.arg(use)
	numNA = sum(is.na(x)) + sum(is.na(y))
	if((numNA > 0) && (use=="pairwise.complete.obs")) {
		subfn <- if(cosine)
			function(a) na.sub(a, 0)
		else
			function(a) na.sub(a, mean(a, na.rm=TRUE))
		x = apply(x, 2, subfn)
		y = apply(y, 2, subfn)
	}
	
	# extract information from data
	design = categorical_design_matrix(group)
	ngroup = ncol(design) # "M" = number of groups
	gidx = 1:ngroup # index along unique groups
	gn = colSums(design) # "n_i" = number of samples in group
	
	# versions of data inversely weighted by group size
	weights = (1/(gn*ngroup))[group]
	xprime = x * weights
	yprime = y * weights
	
	# one-step calculation of means of group mean estimators
	mex = colSums(xprime)       # "bar W1", E[X]   = E_G{E[X|G]}
	mey = colSums(yprime)       # "bar W2", E[Y]   = E_G{E[Y|G]}
	mexy = crossprod(xprime, y) # "bar W3", E[XY]  = E_G{E[XY|G]}
	mexx = colSums(xprime * x)  # "bar W4", E[X^2] = E_G{E[X^2|G]}
	meyy = colSums(yprime * y)  # "bar W5", E[Y^2] = E_G{E[Y^2|G]}
	
	# marginal correlation estimator "g"
	if(cosine) {
		numer = mexy
		denom = tcrossprod(mexx, meyy)
	} else {
		numer = mexy - tcrossprod(mex, mey)
		denom = tcrossprod((mexx - mex^2), (meyy - mey^2))
	}
	est = numer / sqrt(denom)
	if(drop) est = drop(est)
	
	# send it back
	return(est)
}

# Calculate the correlation of the rows of matrices or data frames `x` and `y` (assumed to be of the same dimension) and the two-sided p- and q-values thereof.  The `qval.method`, `qval.precision` and `qval.n` arguments are passed to 		`pvaladj()`.  TO DO:  add Lorenz correlation as a `method` and make `cosine` into its own argument, and possibly add a `use` argument; see `flexcor` for the desired signature.  Also TO DO: compare to `matrix_rows_corrept` below; is one of these obsolete, or can one be made to call the other?  One thing to consider is this method is less flexible in terms of the relative sizes of `x` and `y` than that function.  (DD 2020-11-12)
setMethodS3("matrix_row_correlation_report", "default",
function(x, y,
	method=c("pearson", "spearman", "cosine"), 
	alternative=c("two.sided", "less", "greater"),
	qval.method="BH", qval.precision=PVALADJ_PRECISION,
	qval.n=NULL, rsq=FALSE, ...)
{
	if((nrow(x) != nrow(y)) || (ncol(x) != ncol(y)))
		stop("'x' and 'y' must have the same dimensions")
	
	method = match.arg(method)
	if(method=="spearman") {
		dnx = dimnames(x)
		x = rowRanks(x)
		dimnames(x) = dnx
		dny = dimnames(y)
		y = rowRanks(y)
		dimnames(y) = dny
	}
	alternative = match.arg(alternative)
	
	if(method != "cosine") {
		x = x - rowMeans(x, na.rm=TRUE)
		y = y - rowMeans(y, na.rm=TRUE)
	}
	
	xy = x * y
	isna = is.na(xy)
	numna = rowSums(isna)
	n = ncol(x) - numna
	xy[isna] = 0
	x[isna] = 0
	y[isna] = 0
	
	cor = rowSums(xy) / sqrt(rowSums(x^2) * rowSums(y^2))
	cor[cor > 1] = 1 ; cor[cor < -1] = -1
		# it is impossible by the definition of correlation to have values outside [-1, 1], but sometimes due to numerical instability we may have values outside these bounds by some tiny amount (1e-15, that kind of thing) and this takes care of that problem
	pval = cor_pvalue(cor, n, cosine=(method=="cosine"),
		alternative=alternative)
	qval = pvaladj(pval, method=qval.method, precision=qval.precision, n=qval.n)
	serr = sqrt((1-cor^2) / (ncol(x)-2))
	
	retn = if(rsq)
		data.frame(cor, rsq=cor^2, pval, qval, serr)
	else data.frame(cor, pval, qval, serr)	
	extra.class(retn, "matrix_row_correlation_report")

}, conflict="quiet")

# Do t-tests on the rows of x, optionally compared to the rows of y, and return the results in a data frame. The "precision" and "nadj" arguments are passed to pvaladj().
setMethodS3("matrix_row_t_tests", "default",
function(x, y=NULL, paired=FALSE, two.sided=TRUE, na.rm=TRUE, 
	precision=PVALADJ_PRECISION, nadj=NULL, ...)
{	
	# sanity checks
	if(!is.null(y) && (nrow(x) != nrow(y))) stop(
		"'x' and y must have equal numbers of rows")
	if(paired) {
		if(is.null(y)) stop(
			"'y' cannot be NULL for paired test")
		if(ncol(x) != ncol(y)) stop(
			"'x' and 'y' must have equal numbers of columns for paired test")
	}
	
	# calculate (difference in) means
	xmean = rowMeans(x, na.rm=na.rm)
	if(is.null(y)) {
		value = xmean
	} else {
		ymean = rowMeans(y, na.rm=na.rm)
		xymean = rowMeans(cbind(x, y), na.rm=na.rm)
		value = xmean - ymean
	}
	
	# calculate t-stats
	if(paired) {
		d = x - y
		n = rowSums(!is.na(d))
		sigma = apply(d, 1, sd, na.rm=na.rm) / sqrt(n)
		tstat = rowMeans(d, na.rm=na.rm) / sigma
	} else {
		if(is.null(y)) {
			n = ncol(x)
			sigma = apply(x, 1, sd, na.rm=na.rm) / sqrt(n)
			tstat = xmean / sigma
		} else {
			n1 = ncol(x)
			v1 = apply(x, 1, var, na.rm=na.rm)
			n2 = ncol(y)
			v2 = apply(y, 1, var, na.rm=na.rm)
			sigma = sqrt(v1/n1 + v2/n2)
			tstat = (xmean - ymean) / sigma
		}
	}
	
	# calculate p- and q-values
	df = if(paired || is.null(y)) n-1 else
		(v1/n1 + v2/n2)^2 / ((v1/n1)^2/(n1-1) + (v2/n2)^2/(n2-1))
	pval = if(two.sided)
		pf(tstat^2, 1, df, lower.tail=FALSE)
	else
		pt(tstat, df, lower.tail=FALSE)
	qval = pvaladj(pval, "BH")
	
	# package it up, send it back
	means = if(is.null(y))
		data.frame(xmean)
	else
		data.frame(xmean, ymean, value)
	retn = cbind(means, data.frame(sigma, tstat, pval, qval))
	rownames(retn) = rownames(x)
	attr(retn, "two.sample") = !is.null(y)
	attr(retn, "paired") = paired
	attr(retn, "two.sided") = two.sided
	extra.class(retn, "matrix_row_t_tests")

}, conflict="quiet")

# Calculate the correlation of the rows identified by `xrow` and `yrow` of matrices or data frames `x` and `y`, and the p- and q-values thereof.  If `outer` is TRUE, then all _combinations_ of `xrow` and `yrow` will be reported.  Arguments `method`, `cosine`, `group`, `use`, and `ranked` are as to correlation_report().  Arguments `qval.method`, `qval.precision` and `qval.n` are as to pvaladj().  If `rsq` is TRUE, the R-squared of the correlation will be reported.  If `warn` is TRUE, a warning will be given if `x` and `y` do not have the same column indices or numbers of columns.  If `keep.x` is TRUE, the (massaged) x value will be be returned as an attribute, similarly for `keep.y`.  TO DO: compare to `matrix_row_correlation_report` above; is one of these obsolete, or can one be made to call the other?  One thing to consider is that method is less flexible in terms of the relative sizes of `x` and `y` than this function.  (DD 2020-11-12)
matrix_rows_corrept <- function(x, y, method=c("pearson", "lorenz"), 
	xrow=rownames(x), yrow=rownames(y), outer=FALSE, cosine=FALSE, group=NULL, use=c("all.obs", "pairwise.complete.obs"), ranked=FALSE, alternative=c("two.sided", "less", "greater"), qval.method="BH", qval.precision=PVALADJ_PRECISION, qval.n=NULL, rsq=FALSE, warn=FALSE, keep.x=FALSE, keep.y=FALSE, give.n=FALSE)
{
	# extract arguments
	use = match.arg(use)
	alternative = match.arg(alternative)
	x = dimformat(x)
	if(is.null(xrow)) xrow = rownames(x)
	y = dimformat(y)
	if(is.null(yrow)) yrow = rownames(y)
	if(outer) {
		lg = list_grid(list(x=xrow, y=yrow))
		xrow = lg$x
		yrow = lg$y
	} else if(length(xrow) != length(yrow))
		stop("'xrow' and 'yrow' must be the same length when 'outer' is FALSE")
	if(!is.null(group)) stopifnot(all(names(group)==colnames(x)))
	
	#  munge data as necessary
	common = intersect(colnames(x), colnames(y))
	if(warn) if((length(common) != ncol(x)) || length(common) != ncol(y))
		warning("column indices of 'x' and 'y' are not identical")
	x = x[, common, drop=FALSE]
	y = y[, common, drop=FALSE]
	group = group[common]
	
	# get correlation report, format and return
	retn = data.frame(x=xrow, y=yrow)
	rept = correlation_report(t(as.matrix(x)), t(as.matrix(y)),
		method=method, cosine=cosine, group=group, use=use, ranked=ranked, alternative=alternative)
	retn = cbind(retn, summary(rept, rows=xrow, cols=yrow, give.n=give.n,
		method=qval.method, n=qval.n, precision=qval.precision))
	if(!rsq) retn$rsq = NULL
	retn = extra.class(retn, "matrix_rows_corrept")
	attr(retn, "common") = common
	if(keep.x) attr(retn, "x") = x
	if(keep.y) attr(retn, "y") = y
	return(retn)
}

# Given a matrix or data frame `x` that can be interpreted as logical, return a data frame with columns $row and $col giving the indices of the TRUE elements.  What distinguishes this from `which(x, arr.ind=TRUE)` is that if `x` has named row or column names, the indices will be the relevant names rather than numerical.  Row names of the return value will be in the form "rowsepcol".  TO DO is look for places in the code where ad hoc methods of doing this can be replaced with calls to this function (searching for "arr.ind=TRUE" is probably a good way to do this).
matrix_which <- function(x, sep="_")
{
	retn = which(as.matrix(x), arr.ind=TRUE)
	rownames(retn) = NULL
	retn = as.data.frame(retn)
	
	rx = rownames(x)
	hasrow = !is.null(rx)
	cx = colnames(x)
	hascol = !is.null(cx)
	
	if(hasrow && hascol) {
		retn$row = rx[retn$row]
		retn$col = cx[retn$col]
	} else if(hasrow) {
		retn$row = rx[retn$row]
	} else if(hascol) {
		retn$col = rx[retn$col]
	} # else do nothing
	
	rownames(retn) = make.names(unique=TRUE,
		paste(retn$row, retn$col, sep=sep))
	return(retn)
}

# `max` and `min` functions for factors, which is not part of base R for some reason I cannot even remotely fathom; return value is character
setMethodS3("max", "factor", function(x, ...)
	as.character(x[[which.max(x)]]), conflict="quiet")
setMethodS3("min", "factor", function(x, ...)
	as.character(x[[which.min(x)]]), conflict="quiet")

# Multicore processing convenience functions.  Note there is also mcMap(), a parallel version of Map(), which could be of use.
# utility wrapper for mclapply()
mlapply <- function(X, FUN, ...)
	mclapply(X, FUN, ..., mc.cores=NCORES)
# utility wrapper for mcmapply()
mmapply <- function(FUN, ..., MoreArgs=NULL, SIMPLIFY=TRUE, USE.NAMES=TRUE)
	mcmapply(FUN, ..., MoreArgs=MoreArgs,
		SIMPLIFY=SIMPLIFY, USE.NAMES=USE.NAMES, mc.cores=NCORES)
# multicore version of sapply() depending on mlapply(); code is taken almost verbatim from sapply()
msapply <- function (X, FUN, ..., simplify=TRUE, USE.NAMES=TRUE) 
{
	FUN <- match.fun(FUN)
	answer <- mlapply(X=X, FUN=FUN, ...)
	if (USE.NAMES && is.character(X) && is.null(names(answer))) 
		names(answer) <- X
	if (!identical(simplify, FALSE) && length(answer)) 
		simplify2array(answer, higher = (simplify == "array"))
	else answer
}
# multivariate version of replicate() depending on msapply(); code is taken almost verbatim from replicate()
mreplicate <- function(n, expr, simplify="array")
	msapply(integer(n), eval.parent(substitute(function(...) expr)), 
		simplify=simplify)

# Given a vector, matrix, or data frame `x` containing NA values, substitute `sub`.
.na.sub.default <- function(x) {
	if(is.character(x)) ""
	else if(is.numeric(x)) 0
	else FALSE
}
setMethodS3("na.sub", "default",
function(x, sub=.na.sub.default(x), ...) {
	x[is.na(x)] = sub
	attr(x, "na.action") = list(action="sub", sub=sub)
	return(x)
}, conflict="quiet")
setMethodS3("na.sub", "list",
function(x, ...) {
	subs = list()
	for(i in 1:length(x))
	{
		x[[i]] = na.sub(x[[i]], ...)
		subs[[i]] = attr(x[[i]], "na.action")
	}
	names(subs) = names(x)
	attr(x, "na.action") = subs
	return(x)
}, conflict="quiet")
setMethodS3("na.sub", "data.frame",
	function(x, ...) na.sub.list(x, ...), conflict="quiet")

# Given a matrix or data frame `x` with non-null row names, return a data frame with a leading name column equal to the row names.
name_by_rownames <- function(x, name="name")
{
	if(!isMDF(x) || is.null(rownames(x)))
		stop("'x' must be a matrix or data frame with non-NULL row names")
	
	addon = data.frame(name=rownames(x))
	names(addon) = name
	cbind(addon, as.data.frame(x))
}

# Construct a named list or vector of the objects in `...`
named_list <- function(...)
{
	retn = list(...)
	names(retn) = as.list(substitute(list(...)))[-1L]
	
	return(retn)
}
named_vector <- function(...) unlist(named_list(...))

# Given a numeric vector `x`, plot a histogram and a normal curve.  Argument `main` is passed to the plotting method objects of class "histogram".  NULL gives a default value similar to that for `hist`.  Arguments `...` are passed to the plotting method for `hist`; note that this call will always take place with `freq=FALSE`, so `...` cannot include arguments `freq` or `probability`.  Also `...` cannot include arguments `main`, `plot`, `xlim`, or `ylim`.  Arguments `curve.lty`, `curve.lwd`, and `curve.col` are passed to the `curve` function as `lty`, `lwd`, and `col` respectively.  If `show.test` is TRUE, the p-value for the Jarque-Bera test of normality will be appended to `main` out to `test.digits` significant digits.
normhist <- function(x, main=NULL, ...,
	curve.lty=1, curve.lwd=1, curve.col="black", show.test=TRUE, test.digits=3)
{
	# clean data, get statistics
	x = x[!is.infinite(x)]
	x = x[!is.na(x)]
	mu = mean(x)
	sigma = sd(x)
	
	# prepare but do not plot histogram, then calculate limits: the x-range should always show at least three standard deviations from the mean, while the y-range should include both the greatest density and the normal mode
	h = hist(x, plot=FALSE)
	xlim = range(h$breaks, mu-3*sigma, mu+3*sigma) 
	ylim = range(0, h$density, dnorm(mu, mu, sigma))
	
	# set up main title
	if(is.null(main))
		main = paste("normal histogram of", paste(h$xname, collapse = "\n"))
	if(show.test) {
		pval = jarque.bera.test(x)$p.value[[1]]
		txt = paste("pval =", formatC(pval, test.digits, format="f"))
		if(nchar(main) == 0)
			main = txt
		else
			main = sprintf("%s (%s)", main, txt)
	}
	
	# draw histogram and add curve
	plot(h, main=main, freq=FALSE, xlim=xlim, ylim=ylim, ...)
	curve(dnorm(x, mean=mu, sd=sigma), add=TRUE,
		lty=curve.lty, lwd=curve.lwd, col=curve.col)
	
}

# format "x @ time" notification, preceded by "depth" tabs
notification <- function (x, depth = 0) 
{
    lead = ifelse(depth, paste(rep("\t", depth), collapse=""), "")
    sprintf("%s%s @ %s", lead, x, format(Sys.time(), usetz=TRUE))
}

# extract numeric columns from data frame
numericols <- function(x, include.logical=TRUE)
{
	stopifnot(is.data.frame(x))
	if(include.logical)
		x[sapply(x, function(col) (is.numeric(col) || is.logical(col)))]
	else
		x[sapply(x, is.numeric)]
}

# Given a character vector `x` and named character vector `dict` where some or all of the elements in `x` are in `names(dict)`, return a version of `x` where the names that are present in `names(dict)` are translated to the corresponding values of `dict`.  If `preserve.names` is TRUE, the names of `x` will be kept (note that if `names(x)` is NULL, this means the return value will also have NULL names).  Example:
# x = c("cat", "velociraptor", "dog")
# dict = c(dog="Maggie", parakeet="Dmitri", cat="Raven")
# partial_translate(x, dict) ## [1] "Raven" "velociraptor" "Maggie"
# TO DO:  look for places in the code where this is done on an ad hoc basis and replace with calls to this function, e.g. in list enrichment.
partial_translate <- function(x, dict, preserve.names=TRUE)
{
	nm = names(x)
	idx = which(x %in% names(dict))
	translated = dict[x[idx]]
	x[idx] = translated
	names(x) = nm
	if(!preserve.names) names(x)[idx] = names(translated)
	return(x)
}

# Print a text representation of object `x` to the file `file`; the precise form this takes will depend of what `print` method is applicable to the class of `x`.  Argument `width` is as to `options`; the default value of 10000 is designed to make it very unlikely that printed text will be wrapped.  Arguments `...` are passed to the applicable `print` method.
print2file <- function(x, file, width=10000, ...)
{
	sink(file)
	w = options()$width
	options(width=width)
	print(x, ...)
	options(width=w)
	sink()
}

# Convert values on a [0,1] scale to plot colors.  NA values are returned as gray.  The `separation` parameter moves non-NA values away from the exact center of the color space.  See also `vec2plotcol`.
prob2plotcol <- function(p, separation=0.2, neutralsub=TRUE)
{
	palette = COLOR_BREWER_VALUE_PALETTE
	
	if(separation != 0) {
		if((separation < 0) || (separation >= 0.5))
			stop("'separation' must be >= 0 and < 0.5")
		sepfac = (0.5 - separation) / 0.5
		up = (p > 0.5)
		if(sum(up))
			p[up] = 1 - ((1-p[up]) * sepfac)
		down = (p < 0.5)
		if(sum(down))
			p[down] = p[down] * sepfac
	}
	
	clean = which(!is.na(p))
	pclean = p[clean]
	matclean = colorRamp(palette)(pclean)
	
	dirty = which(is.na(p))
	ndirty = length(dirty)
	if(ndirty) {
		matdirty = matrix(190, nrow=ndirty, ncol=3)
		mat = rbind(matclean, matdirty)[order(c(clean, dirty)), ]
	} else mat = matclean
	
	colnames(mat) = c("red", "green", "blue")
	hex = rgb(mat/255)
	
	retn = data.frame(hex, mat, stringsAsFactors=FALSE)
	if(neutralsub && sum(p==0.5))
		retn[p==0.5, ] = NEUTRAL_COLORS["gray",]
	rownames(retn) = names(p)
	return(retn)
}

# Adjust p-values a la p.adjust(), with some refinements.  First, if `p` is a matrix or data frame, then a matrix or data frame will be returned:  pvaladj() will treat the entire matrix/df `p` as one set of p-values, then return the results with the appropriate shape and row/column names.  Second, optional rounding to `precision` is available; for no rounding, use `precision=NULL` or `precision=NA`.  Third, if `give_min_precision` is TRUE (and `precision` is not NULL or NA) then values less than the minimum possible value allowed by `precision` will be reported as equal to the minimum possible value.  For example, if `precision` is 5 (the default) then any adjusted value <= 0.00001 will be returned as 0.00001.  Uses Benjamini-Hochberg by default, but any "method" argument in p.adjust.methods (see p.adjust()) is allowed.
pvaladj <- function(p, method="BH", n=NULL,
	precision=PVALADJ_PRECISION, give_min_precision=TRUE)
{
	if(is.null(p)) return(NULL)
	
	if(is.matrix(p)) {
		ism = TRUE
		isdf = FALSE
	} else if(is.data.frame(p)) {
		ism = FALSE
		isdf = TRUE
		p = as.matrix(p)
	} else {
		ism = FALSE
		isdf = FALSE
	}	

	if(!is.numeric(p)) stop("'p' must be numeric")
	
	if(is.null(n)) n = length(na.omit(as.vector(p)))
	retn = p.adjust(p, method=method, n=n)
	
	if(is.numeric(precision)) {
		retn = round(retn, precision)
		if(give_min_precision) {
			minval = 10^(-precision)
			retn[retn < minval] = minval
		}
	}
	if(ism || isdf) {
		retn = matrix(retn, ncol=ncol(p))
		dimnames(retn) = dimnames(p)
	} else names(retn) = names(p)
	if(isdf) retn = as.data.frame(retn)
	
	return(retn)
}

# Given a "ragged" list `x`, the elements of which are vectors of various lengths, return a data frame with the elements of `x` in the columns, padded out appropriately.
ragged2df <- function(x, row.names=NULL, keep.names=TRUE, sub=NA, ...)
{
	maxlen = max(lengths(x))
	x = lapply(x, function(y)
	{
		length(y) = maxlen
		if(!is.na(sub)) y[is.na(y)] = sub
		return(y)
	})
	retn = as.data.frame(x, row.names=row.names, ...)
	if(keep.names) names(retn) = names(x)
	return(retn)
}

# Given a vector `x`, scale the vector to lie within the range [0,1] or `[a,b]`
range01 <- function(x)
{
	xmax = max(x, na.rm=TRUE)
	xmin = min(x, na.rm=TRUE)
	
	if(xmin == xmax) # all elements of x are equal
		rep(0.5, length(x))
	else
		(x-xmin)/(xmax-xmin)
}
rangeab <- function(x, a, b)
{
	if(b <= a) stop("'b' must be strictly greater than 'a'")
	(range01(x) * (b-a)) + a
}

# Given two vectors `x` and `y`, return TRUE if their ranges overlap, otherwise FALSE.  The vectors should be of the same or comparable classes; e.g. trying to compare a numeric `x` to a character `y` will give poorly defined results.  No type checking is performed, so be careful.
range_overlap <- function(x, y)
{
	x = range(x)
	y = range(y)

	if(x[1] == y[1])
		TRUE
	else if(x[1] < y[1])
		x[2] >= y[1]
	else # x[1] > y[1]
		x[1] <= y[2]
}

# Given a numeric vector or matrix `x`, set values less than `cut` to 0 and scale other values accordingly.
rangecut <- function(x, cut, negative=FALSE)
{
	if(negative) {
		x = abs(x)
		cut = abs(cut)
	}
	x[x < cut] = 0
	ispos = na.sub(x > 0)
	npos = sum(ispos)
	if(npos > 1) { # otherwise there's no need to scale
		upper = max(x[ispos], na.rm=TRUE)
		lower = upper / npos
		x[ispos] = (upper - lower) * range01(x[ispos]) + lower
	}
	if(negative) -x else x
}

# Given a sortable vector `x`, rank the elements of `x` so that ties always have the same ranks and _there are no gaps_, i.e. ranks go 1, 2, 3, ...  Argument `na.last` is passed to `sort`.  From the elegant "one-liner" at <https://stackoverflow.com/questions/4915704/how-to-get-ranks-with-no-gaps-when-there-are-ties-among-values> with a little added sugar for handling names.
rank_with_no_gaps <- function(x, na.last=TRUE)
	setNames(nm=names(x), match(x, sort(unique(x), na.last=na.last)))

# Recursive list apply:  recursively apply a function `f` to a list `object` containing, at some level, objects of a class appearing in `classes`.  This is a simpler alternative to `base::rapply`.
rlapply <- function(object, f, classes="ANY", ...)
{
	if(is.list(object)) lapply(object, function(x)
		if("ANY" %in% classes)
			f(x, ...)
		else
			if(any(sapply(classes, function(cls) is(x, cls))))
				f(x, ...)
			else if(is.list(x))
				rlapply(x, f, classes, ...)
			else
				if(is.vector(x) && (length(x) > 1))
					rlapply(as.list(x), f, classes, ...)
				else
					NULL
	)
	else if(is.vector(object) && length(object) > 1)
		rlapply(as.list(object), f, classes, ...)
	else
		stop("'object' must be a list")
}

# A modification of `save` that allows saving objects under different names.  For example, if there exists object `foo`, then `save_by_name(bar=foo, file="stuff.RData")` will allow the subsequent execution of `u = load("stuff.RData")` where `u` is the string "bar" and the object `bar` has the contents that were originally in `foo`.  The optional `nm` argument allows passing the new names as a vector of strings:  e.g. `save_by_name(foo, bar, nm=c("foo2", "bar2"), file="baz.RData") creates a file that when loaded will create objects `foo2` and `bar2` with the contents of `foo` and `bar` respectively.  This is essentially the same as the function that appears at <https://stackoverflow.com/questions/21248065/r-rename-r-object-while-save-ing-it> under the name `saveit`.
save_by_name <- function(..., file, nm=NULL)
{
  x = list(...)
  if(!is.null(nm)) names(x) = nm
  save(list=names(x), file=file, envir=list2env(x))
}

# Given objects `x` and `y` suitable for set operations (intersect() etc.) report on numbers of unique and shared elements.
set_count_report <- function(x, y, xname=NULL, yname=NULL,
	percent=TRUE, digits=ifelse(percent, 1, 3), format.names=TRUE)
{
	# extract and preserve names of data
	if(is.null(xname)) xname = deparse(substitute(x))
	if(is.null(yname)) yname = deparse(substitute(y))
	
	# set operations
	x = unique(x)
	y = unique(y)
	xuy = union(x, y)
	xiy = intersect(x, y)
	xny = setdiff(x, y)
	ynx = setdiff(y, x)
	
	# gather statistics
	retn = data.frame(
		xname  = xname,
		yname  = yname,
		x      = length(x),
		y      = length(y),
		total  = length(xuy),
		common = length(xiy),
		xonly  = length(xny),
		yonly  = length(ynx),
		pxgy   = length(xiy) / length(y),
		pygx   = length(xiy) / length(x))
	
	# format as needed and return
	if(percent) {
		retn$pxgy = 100 * retn$pxgy
		retn$pygx = 100 * retn$pygx
	}
	if(!is.null(digits)) {
		fmt = sprintf("%%.%if", digits)
		retn$pxgy = sprintf(fmt, retn$pxgy)
		retn$pygx = sprintf(fmt, retn$pygx)
	}
	if(format.names) {
		if(percent)
			names(retn)[9:10] = c("Pct(x|y)", "Pct(y|x)")
		else
			names(retn)[9:10] = c("Pr(x|y)", "Pr(y|x)")
	}
	return(retn)
}

# Generate and display the PDF user manual for `package`.  Argument `lib.loc` is passed to `find.package`.  Note that the PDF will be created in the current working directory.  By Brian Ripley, posted about haflway down the thread at <http://r.789695.n4.nabble.com/Opening-package-manual-from-within-R-td3763938.html>.
showPDFmanual <- function(package, lib.loc=NULL) 
{ 
	path = find.package(package, lib.loc) 
	system(paste(shQuote(file.path(R.home("bin"), "R")), 
		"CMD", "Rd2pdf", 
	shQuote(path))) 
} 

# Given a string with delimiters such as " %% " representing multiple entries, split by those delimiters, trim whitespace (by default), sort (by default), and paste unique (by default) elements with non-zero length (by default).  Arguments `...` are further arguments to strsplit().
split_and_paste <- function(x, split=" %% ", collapse=split,
	unique.=TRUE, trim.=TRUE, filter.=TRUE, sort.=TRUE, levels.=NULL, ...)
{
	x = unlist(strsplit(x, split=split, ...))
	
	if(unique.) x = unique(x)
	if(trim.)   x = str_trim(x)
	if(filter.) x = Filter(nchar, x)
	
	if(sort.) {
		if(is.null(levels.))
			x = sort(x)
		else
			x = x[order(factor(x, levels=levels.))]
	}
	
	paste(x, collapse=collapse)
}

# Returns a reasonably compact and interpretable trimmed version of most R objects.
trim_anything <- function(x, n=6, nrow.=n, ncol.=n)
{
	if(isMDF(x)) trimmed_table(x, nrow.=nrow., ncol.=ncol.)
	else if(is.list(x))
		lapply(x, trim_anything, n=n, nrow.=nrow., ncol.=ncol.)
	else head(x, n=n)
}

# Given a matrix or data frame `x`, a maximum number of rows to print `nrow.`, a maximum number of columns to print `ncol.`, and optional extra arguments `...` to be passed to format(), return a version of the matrix formatted to fit on screen that will show ellipses for further rows and columns.  For print.trimmed_table(), `...` are passed to print.table().
trimmed_table <- function(x, nrow.=6, ncol.=6, ...)
{
	# sanity check
	if(!isMDF(x)) return(NULL)
	
	# assuming we got through the above, trim down x to appropriate dimension
	if(nrow(x) > (nrow.+1)) x = x[seq(nrow.+1), , drop=FALSE]
	if(ncol(x) > (ncol.+1)) x = x[, seq(ncol.+1), drop=FALSE]
	
	# format rows, columns, and cells for printing
	if((nrow(x) > 0) && is.null(rownames(x)))
		rownames(x) = sprintf("[%i,]", 1:nrow(x))
	if((ncol(x) > 0) && is.null(colnames(x)))
		colnames(x) = sprintf("[,%i]", 1:ncol(x))
	numeric = (is.numeric(x) || is.complex(x)) # preserve for later
	x = format(x, ...)
	
	# add ellipses to rows, columns, and cells to show what was trimmed
	if(nrow(x) > nrow.) {
		x = x[1:(nrow.+1), , drop=FALSE]
		rownames(x)[nrow.+1] = "..."
		if(ncol(x) > 0) x[nrow.+1, ] = "..."
	}

	if(ncol(x) > ncol.) {
		x = x[, 1:(ncol.+1), drop=FALSE]
		colnames(x)[ncol.+1] = "..."
		if(nrow(x) > 0) x[, ncol.+1] = "..."
	}
	
	# send it back with appropriate class information
	retn = extra.class(x, "trimmed_table")
	attr(retn, "numeric") = numeric
	return(retn)
}
setMethodS3("print", "trimmed_table",
function(x, ...)
{
	# remove extraneous attributes in preparation for print.table()
	class(x) = setdiff(class(x), "trimmed_table")
	numeric = attr(x, "numeric")
	attr(x, "numeric") = attr(x, "extra.class") = NULL
	
	# pass to print.table() and we're done
	if(numeric)
        print(x, quote=FALSE, right=TRUE, ...)
    else
    	print(x, quote=FALSE, ...)

}, conflict="quiet")

# Take a vector `x` of values to be converted to plot colors.  Large positive values will be red, with weaker values shading to orange and yellow as they approach 0; large negative values will be blue, with weaker values shading to gray-green-yellow as they approach 0.  If `poscut` is greater than 0, positive values of `x` less than `poscut` will be treated as 0, and values greater than or equal to `poscut` will be scaled accordingly.  If `negcut` is less than 0, positive values of `x` less than `poscut` will be treated as 0, and values greater than or equal to `poscut` will be scaled accordingly.  If `rank` is TRUE, values we be converted to ranks, with separate rankings for positive and negative values.  If `equalize` is TRUE, then the absolute values of the most positive and most negative portions of `x` will be made equal to give equal color balance.  See also prob2plotcol.
vec2plotcol <- function(x, cut=0, negcut=-cut, poscut=cut,
	rank=FALSE, equalize=FALSE, separation=0.2, neutralsub=TRUE)
{
	ispos = na.sub(x > 0)
	haspos = (sum(ispos) > 0)
	isneg = na.sub(x < 0)
	hasneg = (sum(isneg) > 0)
	
	if(haspos && (poscut > 0))
		x[ispos] = rangecut(x[ispos], poscut, negative=FALSE)
	if(hasneg && (negcut < 0))
		x[isneg] = rangecut(x[isneg], negcut, negative=TRUE)
	
	if(rank) {
		if(haspos) x[ispos] = rank(x[ispos])
		if(hasneg) x[isneg] = -rank(abs(x[isneg]))
	}

	if(equalize) {
		p = vector(mode="numeric", length=length(x))
		if(haspos) p[ispos] = x[ispos] / max(x[ispos])
		if(hasneg) p[isneg] = x[isneg] / max(abs(x[isneg]))
	} else p = x

	if(all(p==0))
		p = (p * 0) + 0.5
	else
		p = (1 + p/max(abs(p), na.rm=TRUE)) / 2 # go from [-1, 1] to [0,1] scale
	
	prob2plotcol(p, separation=separation, neutralsub=neutralsub)		
}